<div class="navbar-side">
      <h6>
        <span class="icon"><i class="fas fa-code"></i></span>
        <span class="link-text">Admin</span>
      </h6>
      <ul>
        <li><a href="index.php"  title="Dashboard">
            <span class="icon"><i class="fas fa-chart-bar"></i></span>
            <span class="link-text">Dashboard</span>
          </a></li>
        
        
        <li><a href="flashnews.php" title="Comment">
            <span class="icon"><i class="fas fa-comment"></i></span>
            <span class="link-text">Flash News</span>
          </a></li>
          
        <li><a href="birthdayform.php" title="Profile">
            <span class="icon"><i class="fas fa-user-circle"></i></span>
            <span class="link-text">Birthday</span>
          </a></li>
          <li><a href="achievements.php" title="Profile">
            <span class="icon"><i class="fas fa-user-circle"></i></span>
            <span class="link-text">Achievements</span>
            <li><a href="quote.php" title="Profile">
            <span class="icon"><i class="fas fa-user-circle"></i></span>
            <span class="link-text">Quote</span>
          </a></li>
          </a></li>
        <li><a href="logout.php" title="Sign Out">
            <span class="icon"><i class="fas fa-sign-out-alt"></i></span>
            <span class="link-text">Log Out</span>
          </a></li>
      </ul>
    </div>
